export const environment = {
  production: true,
  appUri: 'http://therabot.me/',
  azure: {
    subscriptionKey: '0fe8f2e6c4c744c2873043e3d14cc5fd',
    uriBase: 'https://eastasia.api.cognitive.microsoft.com/face/v1.0/detect?returnFaceAttributes=emotion',
  },
  firebase: {
    apiKey: 'AIzaSyB7fiA_ejcifqTxuu03c04A9cfb6Ds5rTw',
    authDomain: 'therabot-3bc85.firebaseapp.com',
    databaseURL: 'https://therabot-3bc85.firebaseio.com',
    projectId: 'therabot-3bc85',
    storageBucket: 'therabot-3bc85.appspot.com',
    messagingSenderId: '408349965775'
  },
  auth: {
    clientID: '69CPgotfkX7S3DfA507Xt7pw9KvsnCFN',
    domain: 'therabot.auth0.com',
    audience: 'https://therabot.auth0.com/userinfo',
    redirect: 'https://therabot.me/callback',
    scope: 'openid profile email'
  }
};
