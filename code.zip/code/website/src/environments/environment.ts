// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  appUri: 'http://localhost:4200/',
  azure: {
    subscriptionKey: '0fe8f2e6c4c744c2873043e3d14cc5fd',
    uriBase: 'https://eastasia.api.cognitive.microsoft.com/face/v1.0/detect?returnFaceAttributes=emotion',
  },
  firebase: {
    apiKey: 'AIzaSyB7fiA_ejcifqTxuu03c04A9cfb6Ds5rTw',
    authDomain: 'therabot-3bc85.firebaseapp.com',
    databaseURL: 'https://therabot-3bc85.firebaseio.com',
    projectId: 'therabot-3bc85',
    storageBucket: 'therabot-3bc85.appspot.com',
    messagingSenderId: '408349965775'
  },
  auth: {
    clientID: '69CPgotfkX7S3DfA507Xt7pw9KvsnCFN',
    domain: 'therabot.auth0.com',
    audience: 'https://therabot.auth0.com/userinfo',
    redirect: 'http://localhost:4200/callback',
    scope: 'openid profile email'
  }
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
