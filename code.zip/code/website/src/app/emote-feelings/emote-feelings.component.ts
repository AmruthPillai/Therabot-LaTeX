import { Component, OnInit } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-emote-feelings',
  templateUrl: './emote-feelings.component.html',
  styleUrls: ['./emote-feelings.component.scss']
})
export class EmoteFeelingsComponent implements OnInit {

  public faceData: Array<any>;
  public detectedEmotions = [];
  public url;

  subscriptionKey = environment.azure.subscriptionKey;
  uriBase = environment.azure.uriBase;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/octet-stream',
      'Ocp-Apim-Subscription-Key': this.subscriptionKey
    })
  };

  constructor(private http: HttpClient) { }

  ngOnInit() { }

  public reset() {
    this.faceData = null;
    this.detectedEmotions = [];
    this.url = null;
  }

  public detectEmotion(files) {
    this.http.post<Array<any>>(this.uriBase, files[0], this.httpOptions)
      .subscribe(data => {
        this.faceData = data;
        data.forEach(element => {
          const e = element.faceAttributes.emotion;
          this.detectedEmotions.push(Object.keys(e).reduce((a, b) => e[a] > e[b] ? a : b));
        });
      },
      error => {
        console.error(error);
      });
  }

  public readUrl(ev: any) {
    if (ev.target.files && ev.target.files[0]) {
      const reader = new FileReader();

      reader.onload = (event: any) => {
        this.url = event.target.result;
      };

      reader.readAsDataURL(ev.target.files[0]);
    }
  }

}
