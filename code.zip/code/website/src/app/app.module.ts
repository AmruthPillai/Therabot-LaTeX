import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { MaterialModule } from './material/material.module';
import { BootstrapModule } from './bootstrap/bootstrap.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AuthService } from './services/auth.service';
import { environment } from '../environments/environment';

import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { ServiceWorkerModule } from '@angular/service-worker';
import { CarouselComponent } from './home/carousel/carousel.component';
import { CallbackComponent } from './callback/callback.component';
import { ProfileComponent } from './dashboard/profile/profile.component';
import { FooterComponent } from './footer/footer.component';
import { DearDiaryComponent } from './dear-diary/dear-diary.component';
import { PhotoAlbumComponent } from './photo-album/photo-album.component';
import { EmoteFeelingsComponent } from './emote-feelings/emote-feelings.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    DashboardComponent,
    CarouselComponent,
    CallbackComponent,
    ProfileComponent,
    FooterComponent,
    DearDiaryComponent,
    PhotoAlbumComponent,
    EmoteFeelingsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MaterialModule,
    BootstrapModule,
    AngularFireModule,
    AngularFirestoreModule,
    AngularFirestoreModule.enablePersistence(),
    BrowserAnimationsModule,
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),
  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
