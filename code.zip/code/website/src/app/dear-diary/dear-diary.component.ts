import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dear-diary',
  templateUrl: './dear-diary.component.html',
  styleUrls: ['./dear-diary.component.scss']
})
export class DearDiaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
