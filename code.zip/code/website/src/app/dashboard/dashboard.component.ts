import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public mouseOnCard1: boolean;
  public mouseOnCard2: boolean;
  public mouseOnCard3: boolean;
  public mouseOnCard4: boolean;

  constructor() { }

  ngOnInit() { }

  public gotoMessenger() {
    window.open('https://m.me/therabot.me');
  }

}
