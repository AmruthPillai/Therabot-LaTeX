import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DearDiaryComponent } from './dear-diary/dear-diary.component';
import { PhotoAlbumComponent } from './photo-album/photo-album.component';
import { EmoteFeelingsComponent } from './emote-feelings/emote-feelings.component';
import { CallbackComponent } from './callback/callback.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'dear-diary',
    component: DearDiaryComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'photo-album',
    component: PhotoAlbumComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'emote-feelings',
    component: EmoteFeelingsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'callback',
    component: CallbackComponent
  },
  {
    path: '**',
    redirectTo: 'home'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}

