import { NgModule } from '@angular/core';
import { CarouselModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
    CarouselModule.forRoot()
  ],
  exports: [
    CarouselModule
  ],
  declarations: []
})
export class BootstrapModule { }
