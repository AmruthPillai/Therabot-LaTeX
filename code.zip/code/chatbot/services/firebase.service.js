const admin = require('firebase-admin')
const FieldValue = admin.firestore.FieldValue
const serviceAccount = require('./Therabot-ece122d5ba5b.json')

module.exports = {
  getDB,
  getFieldValue,
  initializeApp
}

let db

function initializeApp () {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
  })

  db = admin.firestore()
}

function getFieldValue () {
  return FieldValue
}

function getDB () {
  return db
}
