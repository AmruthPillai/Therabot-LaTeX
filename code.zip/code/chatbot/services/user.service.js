const request = require('request')

const firebase = require('./firebase.service')

module.exports = {
  saveGoogleUser,
  saveFacebookUser,
  getUser
}

function saveGoogleUser (userId) {
  return new Promise((resolve, reject) => {
    let user = {
      source: 'google',
      createdAt: firebase.getFieldValue().serverTimestamp()
    }

    var userProfileDoc = firebase.getDB().collection('users').doc(userId)
    userProfileDoc.get().then(doc => {
      if (!doc.exists) {
        userProfileDoc.set(user)
      }
    })
  })
}

function saveFacebookUser (userId, firstName, lastName) {
  return new Promise((resolve, reject) => {
    getFacebookData(userId, function (err, userData) {
      if (err) { throw new Error(err) }

      let user = {
        first_name: userData.first_name,
        last_name: userData.last_name,
        profile_pic: userData.profile_pic,
        gender: userData.gender,
        locale: userData.locale,
        source: 'facebook',
        createdAt: firebase.getFieldValue().serverTimestamp()
      }

      var userProfileDoc = firebase.getDB().collection('users').doc(userId)
      userProfileDoc.get().then(doc => {
        if (!doc.exists) {
          userProfileDoc.set(user)
        }
      })
    })
  })
}

function getUser (userId) {
  return new Promise((resolve, reject) => {
    var userProfileDoc = firebase.getDB().collection('users').doc(userId)
    userProfileDoc.get().then(doc => {
      if (doc.exists) {
        return resolve(doc.data())
      }
    })
  })
}

function getFacebookData (facebookId, callback) {
  request({
    method: 'GET',
    url: 'https://graph.facebook.com/v2.8/' + facebookId,
    qs: { access_token: process.env.FB_PAGE_ACCESS_TOKEN }
  }, function (err, response, body) {
    if (err) { throw new Error(err) }
    let userData = JSON.parse(response.body)

    callback(err, userData)
  })
}
