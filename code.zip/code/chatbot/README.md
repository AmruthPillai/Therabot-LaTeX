# Therabot
Therabot is a therapeutic chat-bot that helps users to overcome mental issues like depression, loneliness, PTSD or even procrastination.
