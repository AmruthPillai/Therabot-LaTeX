// To Update User Information
const UserService = require('../services/user.service')

// Conversations
const conversations = require('./conversationsController')

module.exports = (req, res) => {
  // Invoked Action
  console.log('Invoked Action: ' + req.body.queryResult.action)

  // Collect Essential Request Data
  let request = {
    source: req.body.originalDetectIntentRequest,
    queryText: req.body.queryResult.queryText,
    action: req.body.queryResult.action,
    fulfillmentText: req.body.queryResult.fulfillmentText,
    fulfillmentMessages: req.body.queryResult.fulfillmentMessages,
    parameters: req.body.queryResult.parameters,
    allRequiredParamsPresent: req.body.queryResult.allRequiredParamsPresent,
    session: req.body.session
  }

  // Source: Google Assistant
  if (request.source.source === 'google') {
    request.userId = req.body.originalDetectIntentRequest.payload.user.userId

    UserService.saveGoogleUser(request.userId)
  }

  // Source: Facebook
  if (request.source.payload.source === 'facebook') {
    request.userId = req.body.originalDetectIntentRequest.payload.data.sender.id

    UserService.saveFacebookUser(request.userId)
  }

  switch (request.action) {
    case 'reduce_stress.watch_videos':
      conversations.randomVideo.sendRandomYoutubeVideo(res)
      break

    case 'record_journal.get_energy_level.get_journal_entry':
      request.energyLevel = req.body.queryResult.outputContexts[0].parameters.energy_level

      conversations.recordJournal.storeJournalEntry(request.userId, request.energyLevel, request.queryText)
        .then(() => res.send(request.fulfillmentText).end())

      break

    case 'phq9.question1':
      conversations.phq9.storeAnswer(request.userId, 1, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question2':
      conversations.phq9.storeAnswer(request.userId, 2, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question3':
      conversations.phq9.storeAnswer(request.userId, 3, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question4':
      conversations.phq9.storeAnswer(request.userId, 4, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question5':
      conversations.phq9.storeAnswer(request.userId, 5, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question6':
      conversations.phq9.storeAnswer(request.userId, 6, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question7':
      conversations.phq9.storeAnswer(request.userId, 7, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question8':
      conversations.phq9.storeAnswer(request.userId, 8, request.parameters['phq-answers'])
        .then(() => res.send({ fulfillmentMessages: request.fulfillmentMessages }).end())

      break

    case 'phq9.question9':
      conversations.phq9.storeAnswer(request.userId, 9, request.parameters['phq-answers'])
        .then(() => {
          conversations.phq9.calcPhq9Score(request.userId)
            .then((score) => {
              res.send({ fulfillmentText: 'You scored ' + score + ' out of 27. Thank you for taking the test, this helps me understand you much better!' })
            })
        })

      break
  }
}
