// Conversations
const recordJournal = require('../conversations/recordJournal')
const randomVideo = require('../conversations/randomVideo')
const phq9 = require('../conversations/phq9')

module.exports = {
  recordJournal,
  randomVideo,
  phq9
}
