const messageWebhookController = require('./controllers/messageWebhook')

module.exports = function (app) {
  app.get('/', function (req, res) {
    res.send('You must point your chatbot to the /webhook route.')
  })

  app.get('/webhook', function (req, res) {
    res.send('You must POST your request.')
  })

  app.post('/webhook', messageWebhookController)
}
