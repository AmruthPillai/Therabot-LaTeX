const firebase = require('../services/firebase.service')

module.exports = {
  storeAnswer,
  calcPhq9Score
}

function storeAnswer (userId, questionNumber, answer) {
  return new Promise(function (resolve, reject) {
    var phq9Ref = firebase.getDB().collection('users').doc(userId).collection('phq9')

    phq9Ref.doc(questionNumber.toString()).get().then(doc => {
      phq9Ref.doc(questionNumber.toString()).set({
        answer: answer,
        updatedAt: firebase.getFieldValue().serverTimestamp()
      }).then(() => resolve())
    })
  })
}

function calcPhq9Score (userId) {
  return new Promise(function (resolve, reject) {
    var phq9Ref = firebase.getDB().collection('users').doc(userId).collection('phq9')

    let phq9Score = 0
    let questionNumbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
    questionNumbers.forEach(questionNumber => {
      getPhq9Score(phq9Ref, questionNumber)
        .then(answer => {
          phq9Score += answer

          if (questionNumber === '9') {
            phq9Ref.doc('total').set({
              totalScore: phq9Score,
              updatedAt: firebase.getFieldValue().serverTimestamp()
            })

            return resolve(phq9Score)
          }
        })
    })
  })
}

function getPhq9Score (phq9Ref, questionNumber) {
  return new Promise(function (resolve, reject) {
    phq9Ref.doc(questionNumber).get().then(doc => {
      return resolve(parseInt(doc.data().answer))
    })
  })
}
