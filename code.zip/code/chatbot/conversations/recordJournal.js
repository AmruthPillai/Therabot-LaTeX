const firebase = require('../services/firebase.service')

module.exports = {
  storeJournalEntry
}

function storeJournalEntry (userId, energyLevel, journalEntry) {
  return new Promise(function (resolve, reject) {
    var journalsRef = firebase.getDB().collection('users').doc(userId).collection('journals')

    journalsRef.add({
      energyLevel,
      journalEntry
    }).then(function (docRef) {
      docRef.update({ updatedAt: firebase.getFieldValue().serverTimestamp() })
      resolve()
    })
  })
}
