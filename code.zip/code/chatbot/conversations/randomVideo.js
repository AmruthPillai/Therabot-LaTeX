module.exports = {
  sendRandomYoutubeVideo
}

function sendRandomYoutubeVideo (res) {
  return new Promise(function (resolve, reject) {
    let randomFunnyVideo = funnyVideos[Math.floor(Math.random() * funnyVideos.length)]
    res.send({
      'payload': {
        'google': {
          'richResponse': {
            'items': [
              {
                'simpleResponse': {
                  'textToSpeech': 'Here\'s a video I think you might like...'
                }
              },
              {
                'basicCard': {
                  'title': 'Suggested Video',
                  'image': {
                    'url': 'https://img.youtube.com/vi/' + randomFunnyVideo + '/0.jpg'
                  },
                  'buttons': [
                    {
                      'title': 'https://www.youtube.com/watch?v=' + randomFunnyVideo,
                      'openUrlAction': {
                        'url': 'https://www.youtube.com/watch?v=' + randomFunnyVideo
                      }
                    }
                  ]
                }
              }
            ]
          }
        },
        'facebook': [
          { 'text': 'Alright, here\'s one that\'s pretty funny...' },
          {
            'attachment': {
              'type': 'template',
              'payload': {
                'template_type': 'open_graph',
                'elements': [
                  {
                    'url': funnyVideos[Math.floor(Math.random() * funnyVideos.length)]
                  }
                ]
              }
            }
          },
          {
            'text': 'How about one more? 😄',
            'quick_replies': [
              {
                'content_type': 'text',
                'title': '🙂 Yes',
                'payload': 'Watch another video'
              },
              {
                'content_type': 'text',
                'title': '🙁 No',
                'payload': 'NO'
              }
            ]
          }
        ]
      }
    }).end()
  })
}

let funnyVideos = [
  'M1djO19aSFQ',
  'iPW75ZO4pIA',
  'aEzZLXBH3rU',
  '9KZComfMmGo',
  'GIc3aFVv6-E'
]
