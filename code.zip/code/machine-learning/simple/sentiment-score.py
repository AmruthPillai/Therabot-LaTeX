#Sentiment Analysis
'''
1. Calculate the sentiment score of the line of text(POS Tagger)
2. Extract the words of interest

'''
import nltk
import firebase_initialize
from nltk.tokenize import word_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer

str1 = "i WAS appreciated for my creative nlp project"
str7 = "i like ppts, i AM not unhappy with the presentation"
str2 = "I like Dulqueer Salmaan"
str3 = "i LIKE YELLOW FRUITS"
str4 = 'The incredibly intimidating NLP scares people away'
str5 = "i like the purple color of your wall"
category_list, phrases = set([]), set([])

#Begin - Sentiment and Keyword Extract Function 
def sentiment_extract(chosen_str, userId):
    sid = SentimentIntensityAnalyzer()
    print(chosen_str)
    ss = sid.polarity_scores(chosen_str)
    '''
    param k: neg/neu/pos/compound
    param ss[k]: score
    '''
    #Max of the 3 sentiments
    positive = ss['pos']
    negative = ss['neg']
    neutral = ss['neu']
    compound = ss['compound']
        
    if positive>negative:
        sentiment_score = positive
        sentiment_type = 'positive'
    else:
        sentiment_score = negative
        sentiment_type = 'negative'
        
        #for k in ss:
        #    print('{0}: {1}, '.format(k, ss[k]), end='')
        
    print(sentiment_score, sentiment_type)
        
    text = word_tokenize(chosen_str.lower())  
    data = nltk.pos_tag(text)
    print(data)
        
    list_tagger = ['NN', 'VB', 'NNS', 'JJ']
    list_neglect = ['i', 'for', 'with','like','hate', 'favorite', 'horrible', 'unhappy']
    list_neighbor_tags = ['JJ', 'NN', 'NNS']
    pp_word, pp_tag, prev_tag, prev_word, count, prev_count = None, None, None, None, 0, 0
    
    each_phrase = ''
    len=0
    for word,tag in data:
        count = count+1
        if word in list_happy or word in list_sad or word in list_likes or word in list_dislikes or word in list_fears:
            category_list.add(word)
        if tag in list_tagger and word not in list_neglect: 
            #Combine two related words
            if prev_tag in list_neighbor_tags and count-prev_count <= 1:
                if(len==0):
                    each_phrase = each_phrase + prev_word + ' ' + word + ' '
                    len=1
                else:
                    each_phrase = each_phrase + ' ' + word + ' '
                #print(prev_word, word, count, prev_count)
                #print(each_phrase)
                phrases.add(each_phrase)
            else:
                if prev_count is not 0:
                    #phrases.add(each_phrase)
                    phrases.add(word)
                    #print(word, count, prev_count)
            prev_tag, prev_word, prev_count = tag, word, count  
    push_data_to_db(sentiment_score, sentiment_type)
#End - Sentiment Extract Function
            
list_happy = ['pleasure', 'delight', 'joy', 'happy']            
list_likes = ['adore', 'like']
list_dislikes = ['dislike', 'hate', 'bad']
list_fears = ['scary', 'scares', 'afraid']
list_sad = ['sorrow', 'cry']
            
#Begin - Push to firebase
def push_data_to_db(sentiment_score, sentiment_type):
    u = 'u'
    
    for w in category_list:
        for p in phrases:
            data = {
                    p: {
                          u'checked': u'no',
                          u'score': sentiment_score, 
                          u'type': sentiment_type  
                    }
            }
            new_doc_ref = doc_ref.document(userId).collection(u'keywords').document(w)
            new_doc_ref.update(data, firestore.CreateIfMissingOption(True))
#End - Push to firebase       
            
userId = '1526158037467949'
sentiment_extract(str5, userId)
#push_data_to_db()
print('****')
for w in category_list:
    print(w)
print('****')
for w in phrases:
    print(w)
print('****')
print(doc_ref)
