import re

def get_responses():
    #Function start
    print("--User asks something--", '\nReturn a Response')
    #Function end

def set_responses():
    #Function start
    print("Thanks for the answer!")
    #Function end
    
#Start Talking to Therabot
print('Therabot Here!')
print('Say Ask or Answer Questions to Get Started!')

'''
bot for asking questions and learning
1. gather questions and ask
2. store the response and question as a pair

bot to answer
1. gather question answer pair, based on the similarity(of the category) to the question return a response
2. check the question, response pair and reply
'''
a = input().lower()
if re.match('ask', a):
    print("Okay, go on ask me something.")
    get_responses()
elif re.match('answer', a):
    print("Okay, here are some things I'm preoccupied with.")
    set_responses()
else:
    print('Invalid Input')