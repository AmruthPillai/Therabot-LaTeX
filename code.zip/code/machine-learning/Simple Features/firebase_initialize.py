import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Use a service account
cred = credentials.Certificate('Therabot-ece122d5ba5b.json')
#firebase_admin.initialize_app(cred)

db = firestore.client()

doc_ref = db.collection(u'users')

'''
.collection('dislikes').document('star')

data = {
            u'checked': u'no',
            u'score': sentiment_score, 
            u'type': sentiment_type
    }
doc_ref.set(data, firestore.CreateIfMissingOption(True))
'''


